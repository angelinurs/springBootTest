package com.naru.ex2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
